#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
AI PDF Renamer 工具箱启动器
双击此文件或应用图标启动GUI工具箱
"""

import sys
import os

# Add src directory to Python path (for app bundle)
app_resources_dir = os.path.dirname(__file__)
src_dir = os.path.join(app_resources_dir, "src")
sys.path.insert(0, src_dir)

from src.main import main

if __name__ == "__main__":
    # When run without arguments, the main function will launch the GUI
    main()
