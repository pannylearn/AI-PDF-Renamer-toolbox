#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import json
import re
import time
from typing import Any, Dict, List
import base64
import os

from config import (DEFAULT_MAX_PAGES, DEFAULT_MAX_RETRIES, DEFAULT_MODEL,
                    DEFAULT_RETRY_BASE_DELAY, GEMINI_MODELS, GLM_MODELS)

try:
    import google.generativeai as genai
    from PIL import Image
except ImportError as e:
    print(f"Missing required packages. Please install them:")
    print("pip3 install google-generativeai")
    exit(1)

# Try to import ZhipuAI
try:
    from zhipuai import ZhipuAI
    ZHIPUAI_AVAILABLE = True
except ImportError:
    ZHIPUAI_AVAILABLE = False
    print("Warning: ZhipuAI not installed. GLM models will not be available.")
    print("To install: pip install zhipuai")


class MetadataExtractor:
    """Extracts title, author, and year from PDF images using AI models"""

    def __init__(self, api_key: str, model_name: str = DEFAULT_MODEL):
        """Initialize AI API client"""
        self.model_name = model_name
        
        # Check if model is GLM or Gemini
        if model_name in GLM_MODELS:
            if not ZHIPUAI_AVAILABLE:
                raise ImportError("ZhipuAI library not available for GLM models")
            self.client_type = "glm"
            self.client = ZhipuAI(api_key=api_key)
        elif model_name in GEMINI_MODELS:
            self.client_type = "gemini"
            genai.configure(api_key=api_key)
            self.model = genai.GenerativeModel(GEMINI_MODELS[model_name])
        else:
            raise ValueError(
                f"Unknown model: {model_name}. Available models: {list(GEMINI_MODELS.keys()) + list(GLM_MODELS.keys())}"
            )

    def _create_extraction_prompt(self) -> str:
        """Generate prompt for AI metadata extraction"""
        return """
        Analyze this academic paper/document and extract the following information in JSON format:
        
        {
            "title": "Full title of the paper/article",
            "author": "Author name(s) - include all authors if multiple",
            "year": "Year of publication",
            "source_filename": "The filename this data was extracted from"
        }
        
        Instructions:
        - Look for the title, usually prominently displayed at the top
        - Find author information, which might be below the title or in a byline
        - Look for publication year, which might be in various formats (©2015, 2015, etc.)
        - If multiple authors, include all of them
        - If you cannot find specific information, use "Not found" for that field
        - Return only valid JSON, no additional text
        
        Analyze carefully and extract the most accurate information possible.
        """

    def _prepare_image_content(
        self, images: List[Image.Image], pdf_processor, max_pages: int = None
    ) -> List[Dict[str, str]]:
        """Convert images to base64 format for API submission"""
        image_parts = []
        # Limit images to reduce API costs
        num_images = (
            max_pages if max_pages is not None else min(len(images), DEFAULT_MAX_PAGES)
        )
        for image in images[:num_images]:
            data, mime_type = pdf_processor.image_to_base64(image)
            image_parts.append({"mime_type": mime_type, "data": data})
        return image_parts

    def _parse_api_response(self, response, filename: str) -> Dict[str, Any]:
        """Parse and validate JSON response from AI API"""
        try:
            if self.client_type == "glm":
                response_text = response.choices[0].message.content.strip()
            else:  # gemini
                response_text = response.text.strip()

            # Clean markdown code block formatting
            response_text = re.sub(
                r"^```\s*json\s*\n?", "", response_text, flags=re.IGNORECASE
            )
            response_text = re.sub(r"\n?```\s*$", "", response_text)
            response_text = response_text.strip()

            # Extract JSON from response text
            if "{" in response_text and "}" in response_text:
                start = response_text.find("{")
                end = response_text.rfind("}") + 1
                response_text = response_text[start:end]

            result = json.loads(response_text)

            if not isinstance(result, dict):
                return self._create_fallback_response(filename, str(result))

            # Ensure all required fields are present
            required_fields = ["title", "author", "year"]
            for field in required_fields:
                if field not in result:
                    result[field] = "Not found"

            result["source_filename"] = filename
            return result

        except json.JSONDecodeError as e:
            if self.client_type == "glm":
                raw_response = response.choices[0].message.content
            else:  # gemini
                raw_response = response.text
            return self._create_fallback_response(filename, raw_response, str(e))
        except Exception as e:
            if self.client_type == "glm":
                raw_response = response.choices[0].message.content if hasattr(response, 'choices') else str(response)
            else:  # gemini
                raw_response = response.text if hasattr(response, 'text') else str(response)
            return self._create_fallback_response(
                filename, raw_response, f"Unexpected error: {str(e)}"
            )

    def _create_fallback_response(
        self, filename: str, raw_response: str, error: str = None
    ) -> Dict[str, Any]:
        """Create response when JSON parsing fails"""
        return {
            "title": "Could not parse JSON response",
            "author": "Could not parse JSON response",
            "year": "Could not parse JSON response",
            "source_filename": filename,
            "raw_response": (
                raw_response[:500] + "..." if len(raw_response) > 500 else raw_response
            ),
            "parse_error": error,
        }

    def _create_error_response(
        self, error_message: str, filename: str
    ) -> Dict[str, Any]:
        """Create standardized error response"""
        return {
            "title": "Error",
            "author": "Error",
            "year": "Error",
            "source_filename": filename,
            "error": error_message,
        }

    def _is_rate_limit_error(self, error_str: str) -> bool:
        """Check if error is due to API rate limiting"""
        rate_limit_indicators = [
            "429",
            "quota",
            "rate",
            "exceeded",
            "limit",
            "too many requests"
        ]
        error_lower = error_str.lower()
        return any(indicator in error_lower for indicator in rate_limit_indicators)

    def _is_transient_error(self, error_str: str) -> bool:
        """Check if error is temporary and worth retrying"""
        transient_indicators = [
            "timeout",
            "connection",
            "network",
            "temporary",
            "unavailable",
            "service",
            "502",
            "503",
            "504",
            "gateway",
        ]
        error_lower = error_str.lower()
        return any(indicator in error_lower for indicator in transient_indicators)

    def _call_glm_api(self, image_parts, prompt):
        """Call GLM API with image and prompt"""
        # Convert images to GLM format
        glm_images = []
        for img in image_parts:
            glm_images.append({
                "type": "image_url",
                "image_url": {
                    "url": f"data:{img['mime_type']};base64,{img['data']}"
                }
            })
        
        messages = [
            {
                "role": "user",
                "content": glm_images + [{"type": "text", "text": prompt}]
            }
        ]
        
        response = self.client.chat.completions.create(
            model=GLM_MODELS[self.model_name],
            messages=messages,
            temperature=0.1,
        )
        return response

    def _call_gemini_api(self, content_parts):
        """Call Gemini API with content parts"""
        response = self.model.generate_content(content_parts)
        return response

    def extract_metadata_from_images(
        self,
        images: List[Image.Image],
        filename: str,
        pdf_processor,
        max_pages: int = None,
    ) -> Dict[str, Any]:
        """Main method to extract metadata from PDF images with retry logic"""
        if not images:
            return self._create_error_response("No images to process", filename)

        prompt = self._create_extraction_prompt()
        max_retries = DEFAULT_MAX_RETRIES
        base_delay = DEFAULT_RETRY_BASE_DELAY

        # Retry loop with exponential backoff
        for attempt in range(max_retries):
            try:
                image_parts = self._prepare_image_content(
                    images, pdf_processor, max_pages
                )
                
                if self.client_type == "glm":
                    response = self._call_glm_api(image_parts, prompt)
                else:  # gemini
                    content_parts = image_parts + [{"text": prompt}]
                    response = self._call_gemini_api(content_parts)
                
                return self._parse_api_response(response, filename)

            except Exception as e:
                error_message = str(e)

                # Determine if error is retryable and calculate delay
                should_retry = False
                delay = 0

                if self._is_rate_limit_error(error_message):
                    should_retry = True
                    delay = base_delay * (2**attempt)
                    error_type = "Rate limit"
                elif self._is_transient_error(error_message):
                    should_retry = True
                    delay = min(5 * (2**attempt), 60)
                    error_type = "Transient error"

                if should_retry and attempt < max_retries - 1:
                    print(
                        f"⏳ {error_type} for {filename}. Waiting {delay} seconds before retry {attempt + 1}/{max_retries}..."
                    )
                    time.sleep(delay)
                    continue
                elif should_retry:
                    return self._create_error_response(
                        f"{error_type} exceeded after {max_retries} attempts: {error_message}",
                        filename,
                    )
                else:
                    return self._create_error_response(
                        f"API call failed: {error_message}", filename
                    )

        return self._create_error_response(
            f"Failed after {max_retries} attempts", filename
        )