#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import argparse
import os
import time
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List
import tkinter as tk
from tkinter import filedialog, messagebox, ttk
import threading

from config import (DEFAULT_MAX_PAGES, DEFAULT_MODEL, DEFAULT_OUTPUT_FILE,
                    DEFAULT_RATE_LIMIT_DELAY, GEMINI_MODELS, GLM_MODELS, PDF_EXTENSIONS)
from file_manager import FileManager
from metadata_extractor import MetadataExtractor
from pdf_processor import PDFProcessor

try:
    from dotenv import load_dotenv
except ImportError as e:
    print(f"Missing required packages. Please install them:")
    print("pip3 install python-dotenv")
    exit(1)


class PDFMetadataExtractor:
    """Main orchestrator for PDF metadata extraction and file management"""

    def __init__(self, api_key: str, model_name: str = None):
        """Initialize all processing components"""
        self.pdf_processor = PDFProcessor()
        self.metadata_extractor = MetadataExtractor(api_key, model_name)
        self.file_manager = FileManager()

    def _create_error_response(
        self, error_message: str, filename: str
    ) -> Dict[str, Any]:
        """Create standardized error response for processing failures"""
        return {
            "title": "Error",
            "author": "Error",
            "year": "Error",
            "source_filename": filename,
            "error": error_message,
        }

    def process_pdf(
        self,
        pdf_path: str,
        output_dir: str = None,
        copy_files: bool = True,
        max_pages: int = DEFAULT_MAX_PAGES,
    ) -> Dict[str, Any]:
        """Process single PDF file: extract metadata and optionally copy with new name"""
        # Validate input parameters
        if not pdf_path or not isinstance(pdf_path, str):
            return self._create_error_response("Invalid PDF path provided", "unknown")

        if max_pages < 1:
            return self._create_error_response(
                "max_pages must be at least 1", os.path.basename(pdf_path)
            )

        if copy_files and output_dir and not isinstance(output_dir, str):
            return self._create_error_response(
                "Invalid output directory provided", os.path.basename(pdf_path)
            )

        print(f"Processing: {pdf_path}")
        filename = os.path.basename(pdf_path)

        # Convert PDF to images for AI analysis
        images = self.pdf_processor.pdf_to_images(pdf_path, max_pages)
        if not images:
            return self._create_error_response(
                "Failed to convert PDF to images", filename
            )

        # Extract metadata using AI
        metadata = self.metadata_extractor.extract_metadata_from_images(
            images, filename, self.pdf_processor, max_pages
        )

        # Copy file with new name if requested and extraction succeeded
        if copy_files and output_dir and "error" not in metadata:
            copy_result = self.file_manager.copy_pdf_file(
                pdf_path, metadata, output_dir
            )
            metadata["copy_info"] = copy_result

            if copy_result.get("copied"):
                metadata["output_filename"] = copy_result["output_filename"]
                print(f"📝 Copied: {filename} → {copy_result['output_filename']}")

        return metadata

    def process_directory(
        self,
        directory_path: str,
        output_dir: str = None,
        results_file_path: str = None,
        max_pages: int = DEFAULT_MAX_PAGES,
    ) -> List[Dict[str, Any]]:
        """Process all PDF files in a directory with rate limiting and progress tracking"""
        # Validate input parameters
        if not directory_path or not isinstance(directory_path, str):
            print("❌ ERROR: Invalid directory path provided")
            return []

        if max_pages < 1:
            print("❌ ERROR: max_pages must be at least 1")
            return []

        # Validate directory exists and is accessible
        directory = Path(directory_path)
        if not directory.exists():
            print(f"❌ ERROR: Directory does not exist: {directory_path}")
            return []

        if not directory.is_dir():
            print(f"❌ ERROR: Path is not a directory: {directory_path}")
            return []

        if not os.access(directory_path, os.R_OK):
            print(f"❌ ERROR: No read permission for directory: {directory_path}")
            return []

        # Find all PDF files in directory
        results = []
        try:
            pdf_extensions = [ext.replace("*", "") for ext in PDF_EXTENSIONS]
            pdf_files = []
            for f in directory.iterdir():
                if f.is_file() and f.suffix.lower() in [
                    ext.lower() for ext in pdf_extensions
                ]:
                    pdf_files.append(f)
        except PermissionError:
            print(f"❌ ERROR: Permission denied accessing directory: {directory_path}")
            return []
        except Exception as e:
            print(f"❌ ERROR: Failed to scan directory {directory_path}: {e}")
            return []

        if not pdf_files:
            print(f"No PDF files found in {directory_path}")
            return results

        # Display processing summary
        print(f"🔍 Found {len(pdf_files)} PDF files to process")
        if output_dir:
            print(f"📁 Output directory: {os.path.abspath(output_dir)}")
        else:
            print("📄 Metadata extraction only (no file copying)")

        if results_file_path:
            print(
                f"💾 Results will be saved incrementally to: {os.path.abspath(results_file_path)}"
            )

        print(
            f"⏰ Rate limiting: {DEFAULT_RATE_LIMIT_DELAY} seconds between API calls"
        )

        # Process each PDF file with rate limiting
        for i, pdf_file in enumerate(pdf_files, 1):
            processing_start = time.time()
            print(
                f"\n🔄 Processing file {i}/{len(pdf_files)} at {datetime.now().strftime('%H:%M:%S')}"
            )

            # Process individual file
            copy_files = output_dir is not None
            result = self.process_pdf(str(pdf_file), output_dir, copy_files, max_pages)
            results.append(result)

            # Save result incrementally if file specified
            if results_file_path:
                if self.file_manager.update_results_file(results_file_path, result):
                    print(f"📝 Result saved to {os.path.basename(results_file_path)}")
                else:
                    print(
                        f"⚠️  Failed to save result for {result.get('source_filename', 'unknown file')}"
                    )

            # Rate limiting: wait between successful API calls
            if i < len(pdf_files) and "error" not in result:
                processing_time = time.time() - processing_start
                remaining_delay = max(0, DEFAULT_RATE_LIMIT_DELAY - processing_time)
                if remaining_delay > 0:
                    print(
                        f"⏳ Waiting {remaining_delay:.1f} more seconds to respect API rate limits..."
                    )
                    time.sleep(remaining_delay)

        return results


class PDFRenamerGUI:
    """GUI application for PDF renaming tool"""

    def __init__(self, root):
        self.root = root
        self.root.title("AI PDF Renamer 工具箱")
        self.root.geometry("700x500")
        
        # Variables
        self.api_key_var = tk.StringVar()
        self.input_dir_var = tk.StringVar()
        self.output_dir_var = tk.StringVar()
        self.model_var = tk.StringVar(value=DEFAULT_MODEL)
        self.max_pages_var = tk.StringVar(value=str(DEFAULT_MAX_PAGES))
        
        # Load environment variables
        load_dotenv()
        gemini_key = os.getenv("GEMINI_API_KEY", "")
        glm_key = os.getenv("ZHIPUAI_API_KEY", "")
        # Use GLM key if available, otherwise Gemini key
        self.api_key_var.set(glm_key if glm_key else gemini_key)
        
        # Create GUI
        self.create_widgets()
        
        # Processing flag
        self.is_processing = False

    def create_widgets(self):
        # Main frame
        main_frame = ttk.Frame(self.root, padding="10")
        main_frame.grid(row=0, column=0, sticky=(tk.W, tk.E, tk.N, tk.S))
        
        # API Key
        ttk.Label(main_frame, text="API Key:").grid(row=0, column=0, sticky=tk.W, pady=5)
        api_key_frame = ttk.Frame(main_frame)
        api_key_frame.grid(row=0, column=1, columnspan=2, sticky=(tk.W, tk.E), pady=5)
        self.api_key_entry = ttk.Entry(api_key_frame, textvariable=self.api_key_var, width=50, show="*")
        self.api_key_entry.pack(side=tk.LEFT, fill=tk.X, expand=True)
        ttk.Button(api_key_frame, text="显示/隐藏", command=self.toggle_api_key_visibility).pack(side=tk.LEFT, padx=(5,0))
        
        # Model Selection
        ttk.Label(main_frame, text="AI 模型:").grid(row=1, column=0, sticky=tk.W, pady=5)
        model_frame = ttk.Frame(main_frame)
        model_frame.grid(row=1, column=1, columnspan=2, sticky=(tk.W, tk.E), pady=5)
        
        # Combine all available models
        all_models = list(GLM_MODELS.keys()) + list(GEMINI_MODELS.keys())
        self.model_combo = ttk.Combobox(model_frame, textvariable=self.model_var, values=all_models, state="readonly", width=30)
        self.model_combo.pack(side=tk.LEFT)
        ttk.Label(model_frame, text="推荐使用 GLM-4V-Flash").pack(side=tk.LEFT, padx=(10,0))
        
        # Input Directory
        ttk.Label(main_frame, text="PDF 文件夹:").grid(row=2, column=0, sticky=tk.W, pady=5)
        input_frame = ttk.Frame(main_frame)
        input_frame.grid(row=2, column=1, columnspan=2, sticky=(tk.W, tk.E), pady=5)
        ttk.Entry(input_frame, textvariable=self.input_dir_var, width=50).pack(side=tk.LEFT, fill=tk.X, expand=True)
        ttk.Button(input_frame, text="浏览", command=self.browse_input_dir).pack(side=tk.LEFT, padx=(5,0))
        
        # Output Directory
        ttk.Label(main_frame, text="输出文件夹:").grid(row=3, column=0, sticky=tk.W, pady=5)
        output_frame = ttk.Frame(main_frame)
        output_frame.grid(row=3, column=1, columnspan=2, sticky=(tk.W, tk.E), pady=5)
        ttk.Entry(output_frame, textvariable=self.output_dir_var, width=50).pack(side=tk.LEFT, fill=tk.X, expand=True)
        ttk.Button(output_frame, text="浏览", command=self.browse_output_dir).pack(side=tk.LEFT, padx=(5,0))
        
        # Max Pages
        ttk.Label(main_frame, text="分析页数:").grid(row=4, column=0, sticky=tk.W, pady=5)
        pages_frame = ttk.Frame(main_frame)
        pages_frame.grid(row=4, column=1, columnspan=2, sticky=tk.W, pady=5)
        ttk.Entry(pages_frame, textvariable=self.max_pages_var, width=10).pack(side=tk.LEFT)
        ttk.Label(pages_frame, text="页 (默认2页，更多页数会更准确但消耗更多API)").pack(side=tk.LEFT, padx=(10,0))
        
        # Buttons
        button_frame = ttk.Frame(main_frame)
        button_frame.grid(row=5, column=0, columnspan=3, pady=20)
        
        self.start_button = ttk.Button(button_frame, text="开始处理", command=self.start_processing)
        self.start_button.pack(side=tk.LEFT, padx=(0, 10))
        
        self.cancel_button = ttk.Button(button_frame, text="取消", command=self.cancel_processing, state=tk.DISABLED)
        self.cancel_button.pack(side=tk.LEFT, padx=(0, 10))
        
        ttk.Button(button_frame, text="退出", command=self.root.quit).pack(side=tk.LEFT)
        
        # Progress bar
        self.progress = ttk.Progressbar(main_frame, mode='indeterminate')
        self.progress.grid(row=6, column=0, columnspan=3, sticky=(tk.W, tk.E), pady=10)
        
        # Log text area
        ttk.Label(main_frame, text="处理日志:").grid(row=7, column=0, sticky=tk.W, pady=(10, 5))
        self.log_text = tk.Text(main_frame, height=15, width=80)
        log_scrollbar = ttk.Scrollbar(main_frame, orient=tk.VERTICAL, command=self.log_text.yview)
        self.log_text.configure(yscrollcommand=log_scrollbar.set)
        self.log_text.grid(row=8, column=0, columnspan=3, sticky=(tk.W, tk.E, tk.N, tk.S), pady=5)
        log_scrollbar.grid(row=8, column=3, sticky=(tk.N, tk.S), pady=5)
        
        # Configure grid weights
        self.root.columnconfigure(0, weight=1)
        self.root.rowconfigure(0, weight=1)
        main_frame.columnconfigure(1, weight=1)
        main_frame.rowconfigure(8, weight=1)

    def toggle_api_key_visibility(self):
        """Toggle API key visibility"""
        current_show = self.api_key_entry.cget("show")
        self.api_key_entry.config(show="" if current_show == "*" else "*")

    def browse_input_dir(self):
        """Browse for input directory"""
        directory = filedialog.askdirectory()
        if directory:
            self.input_dir_var.set(directory)

    def browse_output_dir(self):
        """Browse for output directory"""
        directory = filedialog.askdirectory()
        if directory:
            self.output_dir_var.set(directory)

    def log_message(self, message):
        """Add message to log"""
        self.log_text.insert(tk.END, message + "\n")
        self.log_text.see(tk.END)
        self.root.update_idletasks()

    def start_processing(self):
        """Start PDF processing in a separate thread"""
        if self.is_processing:
            return
            
        # Validate inputs
        if not self.api_key_var.get().strip():
            messagebox.showerror("错误", "请输入API Key")
            return
            
        if not self.input_dir_var.get().strip():
            messagebox.showerror("错误", "请选择PDF文件夹")
            return
            
        if not self.output_dir_var.get().strip():
            messagebox.showerror("错误", "请选择输出文件夹")
            return
            
        try:
            max_pages = int(self.max_pages_var.get())
            if max_pages < 1:
                raise ValueError("页数必须大于0")
        except ValueError:
            messagebox.showerror("错误", "请输入有效的页数 (正整数)")
            return
            
        # Disable start button and enable cancel button
        self.start_button.config(state=tk.DISABLED)
        self.cancel_button.config(state=tk.NORMAL)
        self.is_processing = True
        self.progress.start()
        
        # Start processing in a separate thread
        thread = threading.Thread(target=self.process_pdfs)
        thread.daemon = True
        thread.start()

    def cancel_processing(self):
        """Cancel processing"""
        self.is_processing = False
        self.start_button.config(state=tk.NORMAL)
        self.cancel_button.config(state=tk.DISABLED)
        self.progress.stop()
        self.log_message("处理已取消")

    def process_pdfs(self):
        """Process PDFs in a separate thread"""
        try:
            # Get parameters
            api_key = self.api_key_var.get().strip()
            input_dir = self.input_dir_var.get().strip()
            output_dir = self.output_dir_var.get().strip()
            model_name = self.model_var.get()
            max_pages = int(self.max_pages_var.get())
            
            # Log parameters
            self.log_message(f"开始处理PDF文件...")
            self.log_message(f"输入目录: {input_dir}")
            self.log_message(f"输出目录: {output_dir}")
            self.log_message(f"AI模型: {model_name}")
            self.log_message(f"分析页数: {max_pages}")
            self.log_message("-" * 50)
            
            # Initialize extractor
            extractor = PDFMetadataExtractor(api_key, model_name)
            self.log_message(f"🔑 API连接已建立 (使用 {model_name} 模型)")
            
            # Process directory
            results_file_path = os.path.join(output_dir, DEFAULT_OUTPUT_FILE)
            results = extractor.process_directory(
                input_dir,
                output_dir,
                results_file_path,
                max_pages
            )
            
            if not self.is_processing:
                return
                
            # Display results
            if not results:
                self.log_message("❌ 未找到或处理成功任何PDF文件")
            else:
                self.log_message("\n" + "=" * 50)
                self.log_message("📊 处理结果")
                self.log_message("=" * 50)
                
                successful_extractions = 0
                copied_files = 0
                for i, result in enumerate(results, 1):
                    self.log_message(f"\n{i}. 📄 文件: {result.get('source_filename', '未知')}")
                    self.log_message("-" * 30)
                    
                    if "error" in result:
                        self.log_message(f"❌ 错误: {result['error']}")
                    else:
                        successful_extractions += 1
                        self.log_message(f"📖 标题:  {result.get('title', '未找到')}")
                        self.log_message(f"👤 作者: {result.get('author', '未找到')}")
                        self.log_message(f"📅 年份:   {result.get('year', '未找到')}")
                        
                        copy_info = result.get("copy_info", {})
                        if copy_info.get("copied"):
                            copied_files += 1
                            self.log_message(f"📝 已复制到: {copy_info['output_filename']}")
                        elif "error" in copy_info:
                            self.log_message(f"⚠️  复制失败: {copy_info['error']}")
                
                self.log_message(f"\n✅ 成功处理 {successful_extractions}/{len(results)} 个文件")
                self.log_message(f"📝 复制了 {copied_files} 个文件到输出目录")
                self.log_message(f"💾 所有结果已保存到: {results_file_path}")
            
            self.log_message("\n🎉 处理完成!")
            
        except Exception as e:
            self.log_message(f"❌ 处理过程中发生错误: {str(e)}")
        finally:
            # Re-enable start button and disable cancel button
            self.root.after(0, self.finish_processing)

    def finish_processing(self):
        """Finish processing and update UI"""
        self.is_processing = False
        self.start_button.config(state=tk.NORMAL)
        self.cancel_button.config(state=tk.DISABLED)
        self.progress.stop()


def parse_arguments():
    """Parse command line arguments for the application"""
    parser = argparse.ArgumentParser(
        description="Extract metadata from PDF files using AI API",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  python3 main.py /path/to/pdfs /path/to/output
  python3 main.py ./data ./output --max-pages 1
  python3 main.py /docs /results --no-copy
  python3 main.py ./papers ./output --model glm-4v-flash
        """,
    )

    parser.add_argument(
        "source",
        nargs='?',
        help="Source directory containing PDF files",
    )

    parser.add_argument(
        "output",
        nargs='?',
        help="Output directory for renamed files",
    )

    parser.add_argument(
        "--no-copy",
        action="store_true",
        help="Only extract metadata, do not copy files",
    )

    parser.add_argument(
        "--max-pages",
        "-p",
        type=int,
        default=DEFAULT_MAX_PAGES,
        help=f"Maximum number of pages to analyze per PDF (default: {DEFAULT_MAX_PAGES})",
    )

    parser.add_argument(
        "--force",
        action="store_true",
        help="Skip interactive confirmations (for automation)",
    )

    parser.add_argument(
        "--model",
        choices=list(GLM_MODELS.keys()) + list(GEMINI_MODELS.keys()),
        default=DEFAULT_MODEL,
        help=f"AI model to use for metadata extraction (default: {DEFAULT_MODEL})",
    )

    return parser.parse_args()


def main():
    """Main entry point for the PDF metadata extractor"""
    args = parse_arguments()
    
    # If no arguments provided, launch GUI
    if not args.source and not args.output:
        root = tk.Tk()
        app = PDFRenamerGUI(root)
        root.mainloop()
        return

    # Validate max_pages parameter
    if args.max_pages < 1:
        print("❌ ERROR: --max-pages must be at least 1")
        return
    # Warn about potentially expensive operations
    if args.max_pages > 10 and not args.force:
        print("⚠️  WARNING: --max-pages > 10 may be slow and expensive for API costs")
        try:
            confirm = input("Continue anyway? (y/N): ").strip().lower()
            if confirm not in ["y", "yes"]:
                print("Operation cancelled.")
                return
        except (EOFError, KeyboardInterrupt):
            print("\nOperation cancelled.")
            return

    # Load environment variables and validate API key
    load_dotenv()

    # Check for GLM API key first, then Gemini
    api_key = os.getenv("ZHIPUAI_API_KEY") or os.getenv("GEMINI_API_KEY")
    if not api_key:
        print("❌ ERROR: API key not found")
        print("Please create a .env file with either:")
        print("  ZHIPUAI_API_KEY=your-glm-api-key")
        print("  GEMINI_API_KEY=your-gemini-api-key")
        return

    # Initialize the main extractor
    try:
        extractor = PDFMetadataExtractor(api_key, args.model)
        print(f"🔑 API connection established (using {args.model} model)")
    except Exception as e:
        print(f"❌ Failed to initialize API: {e}")
        print("Check your API key and internet connection")
        return

    # Process directory paths
    source_dir = os.path.abspath(args.source)
    output_dir = os.path.abspath(args.output)

    if not os.path.exists(source_dir):
        print(f"❌ Source directory {source_dir} does not exist")
        return

    # Display configuration and start processing
    print("🚀 Starting PDF metadata extraction...")
    print(f"📁 Source directory: {source_dir}")
    if not args.no_copy:
        print(f"📂 Output directory: {output_dir}")
    else:
        print("📄 Metadata extraction only (no file copying)")
    print(f"📄 Analyzing first {args.max_pages} pages of each PDF")

    # Determine results file location
    if args.no_copy:
        results_file_path = os.path.join(source_dir, DEFAULT_OUTPUT_FILE)
    else:
        results_file_path = os.path.join(output_dir, DEFAULT_OUTPUT_FILE)

    # Process all files in the directory
    results = extractor.process_directory(
        source_dir,
        output_dir if not args.no_copy else None,
        results_file_path,
        args.max_pages,
    )

    if not results:
        print("❌ No PDF files found or processed successfully")
        return

    # Display final results summary
    print("\n" + "=" * 80)
    print("📊 EXTRACTION RESULTS")
    print("=" * 80)

    # Count successes and display individual results
    successful_extractions = 0
    copied_files = 0
    for i, result in enumerate(results, 1):
        print(f"\n{i}. 📄 File: {result.get('source_filename', 'Unknown')}")
        print("-" * 60)

        if "error" in result:
            print(f"❌ Error: {result['error']}")
        else:
            successful_extractions += 1
            print(f"📖 Title:  {result.get('title', 'Not found')}")
            print(f"👤 Author: {result.get('author', 'Not found')}")
            print(f"📅 Year:   {result.get('year', 'Not found')}")

            if not args.no_copy:
                copy_info = result.get("copy_info", {})
                if copy_info.get("copied"):
                    copied_files += 1
                    print(f"📝 Copied to: {copy_info['output_filename']}")
                elif "error" in copy_info:
                    print(f"⚠️  Copy failed: {copy_info['error']}")

    print(f"\n✅ Successfully processed {successful_extractions}/{len(results)} files")
    if not args.no_copy:
        print(f"📝 Copied {copied_files} files to output directory")

    if results_file_path:
        print(f"💾 All results saved incrementally to: {results_file_path}")

    print("\n🎉 Processing complete!")


if __name__ == "__main__":
    main()