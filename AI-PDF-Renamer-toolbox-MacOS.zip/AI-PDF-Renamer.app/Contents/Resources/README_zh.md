# AI PDF Renamer 工具箱

一个基于AI的PDF文件重命名工具，支持GLM-4V-Flash和Gemini模型。

## 功能特点

- 🧠 支持多种AI模型：GLM-4V-Flash（推荐）、GLM-4V-Plus、Gemini Flash、Gemini Pro
- 🖼️ 通过分析PDF封面自动提取标题、作者和年份信息
- 📁 批量处理整个文件夹中的PDF文件
- 🖱️ 图形界面工具箱，双击即可使用
- ⚙️ 可配置分析页数以平衡准确性和成本

## 安装说明

1. 确保已安装Python 3.7+
2. 安装依赖包：
   ```bash
   pip install -r requirements.txt
   ```
3. 安装系统依赖（macOS）：
   ```bash
   brew install poppler
   ```

## 使用方法

### 方法1：图形界面工具箱（推荐）

双击 `AI-PDF-Renamer.app` 应用图标启动工具箱：

1. 输入您的API密钥（支持ZhipuAI或Google Gemini）
2. 选择包含PDF文件的文件夹
3. 选择输出文件夹
4. 点击"开始处理"

### 方法2：命令行使用

```bash
# 基本用法
python src/main.py /path/to/input/pdfs /path/to/output

# 使用特定模型
python src/main.py /input /output --model glm-4v-flash

# 只分析前3页以提高准确性
python src/main.py /input /output --max-pages 3

# 仅提取元数据，不复制文件
python src/main.py /input /output --no-copy
```

## 配置API密钥

创建 `.env` 文件并添加您的API密钥：

```bash
# ZhipuAI (GLM models)
ZHIPUAI_API_KEY=your-zhipuai-api-key

# 或 Google Gemini
GEMINI_API_KEY=your-gemini-api-key
```

## 模型推荐

- **GLM-4V-Flash**：速度快，成本低，准确率高（推荐）
- **GLM-4V-Plus**：更强大的模型，适合复杂文档
- **Gemini Flash**：Google的快速模型
- **Gemini Pro**：Google的高级模型

## 输出格式

重命名的文件格式：`作者 - 标题 (年份).pdf`

示例：`张三 - 人工智能在PDF处理中的应用 (2024).pdf`

## 故障排除

1. 如果遇到API错误，请检查网络连接和API密钥
2. 如果PDF处理失败，尝试增加分析页数
3. 确保输入文件夹中的PDF文件可读且未损坏

## 许可证

MIT License